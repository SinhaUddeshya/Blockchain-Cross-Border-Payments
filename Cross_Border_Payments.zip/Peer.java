import java.util.ArrayList;
import org.bouncycastle.*;
import java.security.*;

public class Peer {

	public String Name;
	public char[] password;
	public Wallet myWallet; 						//keys for security
	public float balance;							//balance of money
	public String Currency;
	public int type; 								//miner or not
	public double block_reward;
	
	private ArrayList<Peer> restPeers;              //rest peers of blockchain
	
	public Peer(String Name, char[] pass, float balance, int type, String Currency, Wallet myWallet) throws NoSuchProviderException {
		this.Name = Name;
		password = pass;
		this.balance = balance;
		this.type = type;
}
}
