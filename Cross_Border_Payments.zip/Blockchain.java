import java.util.ArrayList;
import java.util.HashMap;
import java.security.*;
import java.util.Base64;
import org.bouncycastle.*;


public class Blockchain {

	public static ArrayList<Block> blockchain = new ArrayList<Block>();
	public static int difficulty = 6;
	public static Transaction genesisTransaction;
	public static Wallet wallet1;
	public static Wallet wallet2;
	public static HashMap<String,TransactionOutput> UTXOs = new HashMap<String,TransactionOutput>(); //list of all unspent transactions. 

	public static void main(String[] args) throws NoSuchProviderException {	
		//add our blocks to the blockchain ArrayList:
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider()); //Setup Bouncy castle as a Security Provider
		//walletA = new Wallet();
		//walletB = new Wallet();
		Wallet funds = new Wallet();
		wallet1 = new Wallet();
		wallet2 = new Wallet();
		Wallet coinbase = new Wallet();
		Wallet miner_wallet = new Wallet();
		genesisTransaction = new Transaction(coinbase.publicKey, funds.publicKey, 1000000000f, null);
		genesisTransaction.generateSignature(coinbase.privateKey);	 //manually sign the genesis transaction	
		genesisTransaction.transactionId = "0"; //manually set the transaction id
		genesisTransaction.outputs.add(new TransactionOutput(genesisTransaction.reciepient, genesisTransaction.amount, genesisTransaction.transactionId)); //manually add the Transactions Output
		UTXOs.put(genesisTransaction.outputs.get(0).id, genesisTransaction.outputs.get(0)); //its important to store our first transaction in the UTXOs list.
				
		System.out.println("Creating and Mining Genesis block... ");
		Block genesis = new Block(0,"0","0");
		genesis.addTransaction(genesisTransaction);
		addBlock(genesis);
	
		char[] password1 = {'p','a','s','s'};
		Peer peer1 = new Peer("UD",password1,100f,0,"gbp",wallet1);
		System.out.println(peer1.balance);
		
		char[] password2 = {'p','a','s','s'};
		Peer peer2 = new Peer("Ky",password2,100f,0,"gbp",wallet2);
		System.out.println(peer2.balance);
		
		char[] password3 = {'p','a','s','s'};
		Peer miner1 = new Peer("UD",password1,100f,1,"gbp",miner_wallet);
		System.out.println(miner1.balance);
		
		Block block1 = new Block(1,"transaction between UD and Ky",genesis.hash);
		System.out.println("\n UD wants to send 20 GBP to KY");
		block1.addTransaction(wallet1.sendFunds(wallet2.publicKey, 20f, "gbp", "nzd"));
		System.out.println("\n UD's new account balance is" +wallet1.getBalance());
		System.out.println("\n Ky's new account balance is" +wallet2.getBalance());
		System.out.println("\n Money Transfered successfully");
		
		Block block2 = new Block(2,"transaction between UD and Ky",block1.hash);
		System.out.println("\n Ky wants to send 200 NZD to UD");
		if(block2.addTransaction(wallet2.sendFunds(wallet1.publicKey, 200f, "nzd", "gbp")))
		{
			System.out.println("Successful");
			block2.addTransaction(wallet1.sendFunds(miner_wallet.publicKey, 10f + 0.6f, "gbp", "gbp"));
			System.out.println("\n Miner1's new account balance is " +miner_wallet.getBalance());
		}
		else
		{
			block2.addTransaction(wallet1.sendFunds(miner_wallet.publicKey, 0.6f, "gbp", "gbp"));
			System.out.println("\n Miner1's new account balance is " +miner_wallet.getBalance());
		}
		//System.out.println("\n UD's new account balance is" +wallet1.getBalance());
		//System.out.println("\n Ky's new account balance is" +wallet2.getBalance());
		//System.out.println("\n Money Transfered successfully");
		
	}
	
	public static Boolean isChainValid() {
		Block currentBlock; 
		Block previousBlock;
		String hashTarget = new String(new char[difficulty]).replace('\0', '0');
		
		//loop through blockchain to check hashes:
		for(int i=1; i < blockchain.size(); i++) {
			currentBlock = blockchain.get(i);
			previousBlock = blockchain.get(i-1);
			//compare registered hash and calculated hash:
			if(!currentBlock.hash.equals(currentBlock.calculateHash()) ){
				System.out.println("Current Hashes not equal");			
				return false;
			}
			//compare previous hash and registered previous hash
			if(!previousBlock.hash.equals(currentBlock.previousHash) ) {
				System.out.println("Previous Hashes not equal");
				return false;
			}
			//check if hash is solved
			if(!currentBlock.hash.substring( 0, difficulty).equals(hashTarget)) {
				System.out.println("This block hasn't been mined");
				return false;
			}
			
		}
		return true;
	}
	
	public static void addBlock(Block newBlock) {
		newBlock.mineBlock(difficulty);
		blockchain.add(newBlock);
	}
}