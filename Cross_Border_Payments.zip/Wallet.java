import java.security.*;
import java.security.spec.ECGenParameterSpec;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Wallet {
	public PrivateKey privateKey;		    // Sign transactions
	public PublicKey publicKey;                              // Address
	public HashMap<String,TransactionOutput> UTXOs = new HashMap<String,TransactionOutput>(); //only UTXOs owned by this wallet.
	public String initial_currency;
	public String final_currency;
	public double conversion_rate;
	
public Wallet() throws NoSuchProviderException{
		generateKeyPair();	
	}
		
	public void generateKeyPair() throws NoSuchProviderException {
		try {
			KeyPairGenerator keyGen = KeyPairGenerator.getInstance("ECDSA","BC");
			SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
			ECGenParameterSpec ecSpec = new ECGenParameterSpec("prime192v1");
			// Initialize the key generator and generate a KeyPair
			keyGen.initialize(ecSpec, random);   //256 bytes provides an acceptable security level
	        	KeyPair keyPair = keyGen.generateKeyPair();
	        	// Set the public and private keys from the keyPair
	        	privateKey = keyPair.getPrivate();
	        	publicKey = keyPair.getPublic();
		}catch(Exception e) {
			throw new RuntimeException(e);
		}
	}
	//returns balance and stores the UTXO's owned by this wallet in this.UTXOs
		public float getBalance() {
			float total = 0;	
	        for (Map.Entry<String, TransactionOutput> item: Blockchain.UTXOs.entrySet()){
	        	TransactionOutput UTXO = item.getValue();
	            if(UTXO.isMine(publicKey)) { //if output belongs to me ( if coins belong to me )
	            	UTXOs.put(UTXO.id,UTXO); //add it to our list of unspent transactions.
	            	total += UTXO.value ; 
	            }
	        }  
			return total;
		}
		//Generates and returns a new transaction from this wallet.
		public Transaction sendFunds(PublicKey _recipient,double value, String initial_currency, String final_currency ) {
			this.initial_currency = initial_currency;
			this.final_currency = final_currency;
			if (initial_currency == final_currency)
			{
				conversion_rate = 1;
			}
			if (initial_currency == "gbp" && final_currency == "eur")
			{
				conversion_rate = 1.12;
			}
			if (initial_currency == "gbp" && final_currency == "chf")
			{
				conversion_rate = 1.26;
			}
			if (initial_currency == "gbp" && final_currency == "usd")
			{
				conversion_rate = 1.27;
			}
			if (initial_currency == "gbp" && final_currency == "nzd")
			{
				conversion_rate = 1.85;
			}
			if (initial_currency == "eur" && final_currency == "gbp")
			{
				conversion_rate = 0.89;
			}
			if (initial_currency == "eur" && final_currency == "chf")
			{
				conversion_rate = 1.13;
			}
			if (initial_currency == "eur" && final_currency == "usd")
			{
				conversion_rate = 1.14;
			}
			if (initial_currency == "eur" && final_currency == "nzd")
			{
				conversion_rate = 1.66;
			}
			if (initial_currency == "chf" && final_currency == "gbp")
			{
				conversion_rate = 0.79;
			}
			if (initial_currency == "chf" && final_currency == "eur")
			{
				conversion_rate = 0.89;
			}
			if (initial_currency == "chf" && final_currency == "usd")
			{
				conversion_rate = 1.01;
			}
			if (initial_currency == "chf" && final_currency == "nzd")
			{
				conversion_rate = 1.47;
			}
			if (initial_currency == "nzd" && final_currency == "gbp")
			{
				conversion_rate = 0.54;
			}
			if (initial_currency == "nzd" && final_currency == "eur")
			{
				conversion_rate = 0.60;
			}
			if (initial_currency == "nzd" && final_currency == "chf")
			{
				conversion_rate = 0.68;
			}
			if (initial_currency == "nzd" && final_currency == "usd")
			{
				conversion_rate = 0.69;
			}
			value = value*conversion_rate;
			if(getBalance() < value) { //gather balance and check funds.
				System.out.println("#Not Enough funds to send transaction. Transaction Discarded.");
				return null;
			}
	    //create array list of inputs
			ArrayList<TransactionInput> inputs = new ArrayList<TransactionInput>();
	    
			float total = 0;
			for (Map.Entry<String, TransactionOutput> item: UTXOs.entrySet()){
				TransactionOutput UTXO = item.getValue();
				total += UTXO.value;
				inputs.add(new TransactionInput(UTXO.id));
				if(total > value) break;
			}
			
			Transaction newTransaction = new Transaction(publicKey, _recipient , value, inputs);
			newTransaction.generateSignature(privateKey);
			
			for(TransactionInput input: inputs){
				UTXOs.remove(input.transactionOutputId);
			}
			return newTransaction;
	}
}